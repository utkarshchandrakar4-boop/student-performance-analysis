# Student Performance Analytics | Python, Excel

Dataset: ~120 students x 4 semesters (4 subjects each) x 4 evaluation types (Quiz, Assignment, Midterm, Final Exam). The data here is synthetic and stands in for anonymised college records. Put your real semester CSVs in `raw/` (columns: Semester, Student ID, Subject, Evaluation Type, Score, Max Marks) and re-run.

## Run
    pip install pandas matplotlib
    python analysis.py

## What analysis.py does
1. **Merge** the four semester files (7,728 raw rows).
2. **Fix inconsistent entries**: semester labels (Sem 1 / S1 / semester 1), evaluation names (Mid Term, mid-term, END SEM, Assgn), subject case and spaces, student-ID case and spaces, scores written as "78%".
3. **Missing and invalid values**: NA, AB, "-" and blanks become missing (5.3% of rows); scores below 0 or above 100 are treated as entry errors; 48 duplicate records are removed. Quiz and Assignment gaps are filled with the student's median for that type in that semester (207 filled). Midterm and Final Exam gaps are removed, never imputed (201 removed). Result: 7,479 clean rows.
4. **EDA**: mean score by semester and evaluation type, change from Sem 1 to Sem 4, fail rate by subject (pass mark 40), score distributions.

## Findings (on this dataset)
- **Final Exam shows the largest drop: 57.8 to 44.5 (-13.3 points)** from Sem 1 to Sem 4. Midterm fell 6.2, Quiz 3.7, Assignment 1.8.
- Overall fail rate rose from 6.9% (Sem 1) to 15.1% (Sem 4).
- **Highest fail rates: Applied Mathematics (21.5%) and Thermodynamics (20.9%)**, then Control Systems (14.5%), Fluid Mechanics (13.3%) and Mathematics-I (13.2%).
- Assignments stay stable, so continuous internal work holds up while end-of-semester exams get harder to pass.

## Suggested actions for stakeholders
Add bridge or remedial sessions before math-heavy subjects, add mock finals, and review Final Exam difficulty against internal assessments.

## Files
`analysis.py` · `raw/` · `clean_student_scores.csv` · `cleaning_log.csv` · `summary_*.csv` · `charts/` (5 PNGs) · `Student_Performance_Analytics.xlsx`
