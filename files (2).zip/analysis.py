"""Student Performance Analytics: merge, clean, EDA. Run: python analysis.py  (needs pandas, matplotlib)"""
import glob, re, os, pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
os.makedirs("charts", exist_ok=True); PASS=40
# 1. MERGE ------------------------------------------------------------------
raw = pd.concat([pd.read_csv(f, dtype=str) for f in sorted(glob.glob("raw/semester_*_raw.csv"))], ignore_index=True)
n0 = len(raw); log = {"raw_rows": n0}
# 2. FIX INCONSISTENT ENTRIES -----------------------------------------------
df = raw.copy()
df["Semester"] = "Sem " + df["Semester"].str.extract(r"(\d)")[0]
df["Student ID"] = df["Student ID"].str.strip().str.upper()
canon = {s.lower(): s for s in df["Subject"].str.strip().unique() if s != s.upper() and s != s.lower()}
df["Subject"] = df["Subject"].str.strip().str.lower().map(canon)
ev_map = {"quiz":"Quiz","assignment":"Assignment","assgn":"Assignment","midterm":"Midterm","mid term":"Midterm","mid-term":"Midterm","final exam":"Final Exam","final":"Final Exam","end sem":"Final Exam"}
df["Evaluation Type"] = df["Evaluation Type"].str.strip().str.lower().map(ev_map)
df["Score"] = pd.to_numeric(df["Score"].str.replace("%","",regex=False).str.strip(), errors="coerce")  # NA, AB, '-', '' -> NaN
assert df[["Semester","Subject","Evaluation Type"]].notna().all().all()
log["unparseable_or_missing_scores"] = int(df.Score.isna().sum())
bad = (df.Score < 0) | (df.Score > 100); log["out_of_range_scores"] = int(bad.sum()); df.loc[bad, "Score"] = np.nan
dup = df.duplicated(["Semester","Student ID","Subject","Evaluation Type"]); log["duplicates_removed"] = int(dup.sum()); df = df[~dup].copy()
# 3. MISSING VALUES: fill quiz/assignment with student's median for that type in that semester; drop midterm/final
miss = df.Score.isna(); log["missing_after_dedup"] = int(miss.sum()); log["missing_pct"] = round(100*miss.mean(), 2)
med = df.groupby(["Semester","Student ID","Evaluation Type"])["Score"].transform("median")
fill = miss & df["Evaluation Type"].isin(["Quiz","Assignment"]) & med.notna()
df.loc[fill, "Score"] = med[fill].round(1); log["filled"] = int(fill.sum())
drop = df.Score.isna(); log["removed"] = int(drop.sum()); df = df[~drop].copy(); log["clean_rows"] = len(df)
df["Result"] = np.where(df.Score >= PASS, "Pass", "Fail")
df.to_csv("clean_student_scores.csv", index=False); pd.Series(log).to_csv("cleaning_log.csv", header=["value"])
# 4. EDA --------------------------------------------------------------------
order_e = ["Quiz","Assignment","Midterm","Final Exam"]
trend = df.pivot_table(index="Evaluation Type", columns="Semester", values="Score", aggfunc="mean").loc[order_e].round(1)
trend["Change Sem1 to Sem4"] = (trend["Sem 4"] - trend["Sem 1"]).round(1)
fail = (df.assign(F=df.Result.eq("Fail")).groupby("Subject").agg(Records=("F","size"), Fail_Rate_Pct=("F", lambda x: round(100*x.mean(),1)), Avg_Score=("Score","mean")).round(1).sort_values("Fail_Rate_Pct", ascending=False))
sem_sum = df.groupby("Semester").agg(Avg_Score=("Score","mean"), Fail_Rate_Pct=("Result", lambda x: 100*(x=="Fail").mean())).round(1)
trend.to_csv("summary_trend_by_eval.csv"); fail.to_csv("summary_fail_rate_by_subject.csv"); sem_sum.to_csv("summary_by_semester.csv")
big = trend["Change Sem1 to Sem4"].idxmin(); print(log); print(trend); print(fail.head(6)); print(sem_sum); print("Largest drop:", big)
# 5. CHARTS -----------------------------------------------------------------
C = {"Quiz":"#7aa7d9","Assignment":"#5cae8a","Midterm":"#e0a040","Final Exam":"#c8372d"}
fig, ax = plt.subplots(figsize=(7,4))
for e in order_e: ax.plot(["Sem 1","Sem 2","Sem 3","Sem 4"], trend.loc[e, ["Sem 1","Sem 2","Sem 3","Sem 4"]], marker="o", label=e, color=C[e])
ax.set_title("Average score by semester and evaluation type"); ax.set_ylabel("Average score (out of 100)"); ax.legend(); ax.grid(alpha=.3); fig.tight_layout(); fig.savefig("charts/1_trend_by_eval.png", dpi=150); plt.close()
fig, ax = plt.subplots(figsize=(6,3.6)); ch = trend["Change Sem1 to Sem4"]
ax.barh(ch.index, ch.values, color=[C[i] for i in ch.index]); ax.set_title("Score change, Sem 1 to Sem 4"); ax.set_xlabel("Points")
for i,v in enumerate(ch.values): ax.text(v, i, f" {v:+.1f}", va="center")
fig.tight_layout(); fig.savefig("charts/2_score_drop_by_eval.png", dpi=150); plt.close()
fig, ax = plt.subplots(figsize=(7,4.4)); f = fail.sort_values("Fail_Rate_Pct")
ax.barh(f.index, f.Fail_Rate_Pct, color=["#c8372d" if v>=f.Fail_Rate_Pct.quantile(.75) else "#7aa7d9" for v in f.Fail_Rate_Pct]); ax.set_title(f"Fail rate by subject (score below {PASS})"); ax.set_xlabel("% of records")
fig.tight_layout(); fig.savefig("charts/3_fail_rate_by_subject.png", dpi=150); plt.close()
fig, ax = plt.subplots(figsize=(7,4)); ax.boxplot([df[df["Evaluation Type"]==e].Score for e in order_e], tick_labels=order_e, patch_artist=True)
ax.axhline(PASS, color="red", ls="--", lw=1); ax.set_title("Score distribution by evaluation type"); ax.set_ylabel("Score"); fig.tight_layout(); fig.savefig("charts/4_distribution_by_eval.png", dpi=150); plt.close()
fig, ax = plt.subplots(figsize=(7,4)); 
for s,c in zip(["Sem 1","Sem 4"],["#7aa7d9","#c8372d"]): ax.hist(df[(df.Semester==s)&(df["Evaluation Type"]=="Final Exam")].Score, bins=20, alpha=.6, label=f"{s} Final Exam", color=c)
ax.set_title("Final Exam score distribution: Sem 1 vs Sem 4"); ax.set_xlabel("Score"); ax.legend(); fig.tight_layout(); fig.savefig("charts/5_final_exam_hist.png", dpi=150); plt.close()
